"use client"

import { FormEvent, useEffect, useMemo, useState } from "react"
import Link from "next/link"
import {
  CalendarDays,
  ChevronRight,
  Edit3,
  Plus,
  RefreshCw,
  Save,
  ShieldCheck,
  Trash2,
  Users,
  X,
} from "lucide-react"
import { api } from "@/lib/api"
import type { Player, Team, TournamentDay, User } from "@/lib/types"
import { Button, Card, ErrorBox, Input, Loading, PageTitle } from "@/components/ui"

type Section = "teams" | "players" | "days"

type DayForm = {
  tournament_id: number
  name: string
  teams: number[]
  room_count: number
  deadline_at: string
}

const emptyDayForm: DayForm = {
  tournament_id: 1,
  name: "",
  teams: [],
  room_count: 4,
  deadline_at: "",
}

export default function AdminPage() {
  const [user, setUser] = useState<User | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [teams, setTeams] = useState<Team[]>([])
  const [players, setPlayers] = useState<Player[]>([])
  const [days, setDays] = useState<TournamentDay[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<unknown>(null)
  const [notice, setNotice] = useState("")
  const [section, setSection] = useState<Section>("teams")

  const [newTeam, setNewTeam] = useState("")
  const [editingTeam, setEditingTeam] = useState<number | null>(null)
  const [editingTeamName, setEditingTeamName] = useState("")

  const [newPlayerName, setNewPlayerName] = useState("")
  const [newPlayerTeam, setNewPlayerTeam] = useState(0)
  const [editingPlayer, setEditingPlayer] = useState<number | null>(null)
  const [editingPlayerName, setEditingPlayerName] = useState("")
  const [editingPlayerTeam, setEditingPlayerTeam] = useState(0)

  const [dayForm, setDayForm] = useState<DayForm>(emptyDayForm)
  const [editingDay, setEditingDay] = useState<number | null>(null)

  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)

  const playerByTeam = useMemo(() => {
    const map = new Map<number, Player[]>()
    for (const team of teams) map.set(team.id, [])
    for (const player of players) map.get(player.team_id)?.push(player)
    return map
  }, [teams, players])

  async function loadData() {
    setLoading(true)
    setError(null)
    try {
      const [teamData, dayData] = await Promise.all([api.teams(), api.tournamentDays()])
      const playerData = await Promise.all(teamData.map((team) => api.players(team.id)))
      setTeams(teamData)
      setPlayers(playerData.flat())
      setDays(dayData)
      if (teamData.length && !newPlayerTeam) setNewPlayerTeam(teamData[0].id)
    } catch (e) {
      setError(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    api.me()
      .then((me) => {
        setUser(me)
        if (me.role === "admin") loadData()
      })
      .catch((e) => setError(e))
      .finally(() => setAuthLoading(false))
  }, [])

  function clearMessages() {
    setError(null)
    setNotice("")
  }

  async function run(action: () => Promise<void>, message: string) {
    clearMessages()
    setSaving(true)
    try {
      await action()
      setNotice(message)
      await loadData()
    } catch (e) {
      setError(e)
    } finally {
      setSaving(false)
    }
  }

  async function createTeam(event: FormEvent) {
    event.preventDefault()
    const name = newTeam.trim()
    if (!name) return
    await run(async () => {
      await api.adminCreateTeam(name)
      setNewTeam("")
    }, "Team created.")
  }

  async function saveTeam(id: number) {
    const name = editingTeamName.trim()
    if (!name) return
    await run(async () => {
      await api.adminUpdateTeam(id, name)
      cancelTeamEdit()
    }, "Team updated.")
  }

  async function deleteTeam(team: Team) {
    if (!confirm(`Delete “${team.name}”? This may fail if the team is still referenced by players or tournament data.`)) return
    clearMessages()
    setDeleting(`team-${team.id}`)
    try {
      await api.adminDeleteTeam(team.id)
      setNotice("Team deleted.")
      await loadData()
    } catch (e) {
      setError(e)
    } finally {
      setDeleting(null)
    }
  }

  function startTeamEdit(team: Team) {
    clearMessages()
    setEditingTeam(team.id)
    setEditingTeamName(team.name)
  }

  function cancelTeamEdit() {
    setEditingTeam(null)
    setEditingTeamName("")
  }

  async function createPlayer(event: FormEvent) {
    event.preventDefault()
    const nickname = newPlayerName.trim()
    if (!nickname || !newPlayerTeam) return
    await run(async () => {
      await api.adminCreatePlayer(newPlayerTeam, nickname)
      setNewPlayerName("")
    }, "Player created.")
  }

  function startPlayerEdit(player: Player) {
    clearMessages()
    setEditingPlayer(player.id)
    setEditingPlayerName(player.nickname)
    setEditingPlayerTeam(player.team_id)
  }

  function cancelPlayerEdit() {
    setEditingPlayer(null)
    setEditingPlayerName("")
    setEditingPlayerTeam(0)
  }

  async function savePlayer(id: number) {
    const nickname = editingPlayerName.trim()
    if (!nickname || !editingPlayerTeam) return
    await run(async () => {
      await api.adminUpdatePlayer(id, editingPlayerTeam, nickname)
      cancelPlayerEdit()
    }, "Player updated.")
  }

  async function deletePlayer(player: Player) {
    if (!confirm(`Delete player “${player.nickname}”?`)) return
    clearMessages()
    setDeleting(`player-${player.id}`)
    try {
      await api.adminDeletePlayer(player.id)
      setNotice("Player deleted.")
      await loadData()
    } catch (e) {
      setError(e)
    } finally {
      setDeleting(null)
    }
  }

  function toggleDayTeam(teamId: number) {
    setDayForm((current) => ({
      ...current,
      teams: current.teams.includes(teamId)
        ? current.teams.filter((id) => id !== teamId)
        : [...current.teams, teamId],
    }))
  }

  function toLocalDateTime(iso: string) {
    if (!iso) return ""
    const date = new Date(iso)
    const offset = date.getTimezoneOffset() * 60000
    return new Date(date.getTime() - offset).toISOString().slice(0, 16)
  }

  function startDayEdit(day: TournamentDay) {
    clearMessages()
    setEditingDay(day.id)
    setDayForm({
      tournament_id: day.tournament_id,
      name: day.name,
      teams: [...day.teams],
      room_count: day.room_count,
      deadline_at: toLocalDateTime(day.deadline_at),
    })
    setSection("days")
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  function cancelDayEdit() {
    setEditingDay(null)
    setDayForm(emptyDayForm)
  }

  async function saveDay(event: FormEvent) {
    event.preventDefault()
    if (!dayForm.name.trim()) return
    if (!dayForm.teams.length) {
      setError(new Error("Select at least one participating team."))
      return
    }
    if (!dayForm.deadline_at) {
      setError(new Error("Choose a deadline."))
      return
    }

    const payload = {
      ...dayForm,
      name: dayForm.name.trim(),
      teams: dayForm.teams,
      room_count: Math.max(1, Number(dayForm.room_count)),
      deadline_at: new Date(dayForm.deadline_at).toISOString(),
    }

    await run(async () => {
      if (editingDay) await api.adminUpdateDay(editingDay, payload)
      else await api.adminCreateDay(payload)
      cancelDayEdit()
    }, editingDay ? "Tournament day updated." : "Tournament day created.")
  }

  async function deleteDay(day: TournamentDay) {
    if (!confirm(`Delete “${day.name}”? Its rooms and related data may be affected.`)) return
    clearMessages()
    setDeleting(`day-${day.id}`)
    try {
      await api.adminDeleteDay(day.id)
      if (editingDay === day.id) cancelDayEdit()
      setNotice("Tournament day deleted.")
      await loadData()
    } catch (e) {
      setError(e)
    } finally {
      setDeleting(null)
    }
  }

  if (authLoading) return <Loading label="Checking admin access…" />

  if (!user) {
    return (
      <main className="mx-auto max-w-xl px-5 py-24 lg:px-8">
        <Card className="p-8">
          <ShieldCheck className="size-9 text-[#f4d35e]" />
          <h1 className="mt-5 font-mono text-3xl font-black">Admin sign-in required</h1>
          <p className="mt-3 text-sm leading-6 text-zinc-500">Log in with an account that has the admin role.</p>
          <Link href="/login" className="mt-6 inline-flex rounded-xl bg-[#f4d35e] px-4 py-2.5 text-sm font-bold text-[#17130a]">Log in</Link>
        </Card>
      </main>
    )
  }

  if (user.role !== "admin") {
    return (
      <main className="mx-auto max-w-xl px-5 py-24 lg:px-8">
        <Card className="p-8">
          <ShieldCheck className="size-9 text-red-300" />
          <h1 className="mt-5 font-mono text-3xl font-black">Access denied</h1>
          <p className="mt-3 text-sm leading-6 text-zinc-500">Your account is not an administrator. The backend also protects every write endpoint.</p>
          <Link href="/" className="mt-6 inline-flex rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold">Back home</Link>
        </Card>
      </main>
    )
  }

  return (
    <main className="mx-auto max-w-7xl px-5 py-12 lg:px-8 lg:py-16">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <PageTitle
          eyebrow="Administrator"
          title="Control room"
          description="Manage the tournament roster, tournament days and player room statistics. Reads stay public; every mutation is sent to an admin-only Go endpoint."
        />
        <Button variant="secondary" onClick={() => loadData()} loading={loading}>
          <RefreshCw className="size-4" /> Refresh
        </Button>
      </div>

      <div className="mt-7 space-y-3">
        <ErrorBox error={error} />
        {notice && <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">{notice}</div>}
      </div>

      <div className="mt-10 grid gap-3 sm:grid-cols-3">
        <StatCard icon={<Users className="size-5" />} label="Teams" value={teams.length} />
        <StatCard icon={<Users className="size-5" />} label="Players" value={players.length} />
        <StatCard icon={<CalendarDays className="size-5" />} label="Tournament days" value={days.length} />
      </div>

      <div className="mt-10 flex flex-wrap gap-2 border-b border-white/10 pb-3">
        <AdminTab active={section === "teams"} onClick={() => setSection("teams")}>Teams</AdminTab>
        <AdminTab active={section === "players"} onClick={() => setSection("players")}>Players</AdminTab>
        <AdminTab active={section === "days"} onClick={() => setSection("days")}>Tournament days</AdminTab>
        <Link href="/admin/stats" className="rounded-xl px-4 py-2.5 text-sm font-semibold text-zinc-500 transition hover:bg-white/[.04] hover:text-white">Room stats <ChevronRight className="ml-1 inline size-4" /></Link>
      </div>

      {loading ? (
        <div className="mt-8"><Loading label="Loading admin data…" /></div>
      ) : section === "teams" ? (
        <TeamsSection
          teams={teams}
          newTeam={newTeam}
          setNewTeam={setNewTeam}
          editingTeam={editingTeam}
          editingTeamName={editingTeamName}
          setEditingTeamName={setEditingTeamName}
          saving={saving}
          deleting={deleting}
          onCreate={createTeam}
          onStartEdit={startTeamEdit}
          onSave={saveTeam}
          onCancel={cancelTeamEdit}
          onDelete={deleteTeam}
        />
      ) : section === "players" ? (
        <PlayersSection
          teams={teams}
          players={players}
          playerByTeam={playerByTeam}
          newPlayerName={newPlayerName}
          newPlayerTeam={newPlayerTeam}
          setNewPlayerName={setNewPlayerName}
          setNewPlayerTeam={setNewPlayerTeam}
          editingPlayer={editingPlayer}
          editingPlayerName={editingPlayerName}
          editingPlayerTeam={editingPlayerTeam}
          setEditingPlayerName={setEditingPlayerName}
          setEditingPlayerTeam={setEditingPlayerTeam}
          saving={saving}
          deleting={deleting}
          onCreate={createPlayer}
          onStartEdit={startPlayerEdit}
          onSave={savePlayer}
          onCancel={cancelPlayerEdit}
          onDelete={deletePlayer}
        />
      ) : (
        <DaysSection
          teams={teams}
          days={days}
          form={dayForm}
          editingDay={editingDay}
          saving={saving}
          deleting={deleting}
          setForm={setDayForm}
          onToggleTeam={toggleDayTeam}
          onSubmit={saveDay}
          onStartEdit={startDayEdit}
          onCancel={cancelDayEdit}
          onDelete={deleteDay}
        />
      )}
    </main>
  )
}

function AdminTab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button onClick={onClick} className={`rounded-xl px-4 py-2.5 text-sm font-semibold transition ${active ? "bg-[#f4d35e] text-[#17130a]" : "text-zinc-500 hover:bg-white/[.04] hover:text-white"}`}>{children}</button>
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return <Card className="p-5"><div className="flex items-center justify-between"><span className="grid size-10 place-items-center rounded-xl bg-[#f4d35e]/10 text-[#f4d35e]">{icon}</span><span className="font-mono text-3xl font-black">{value}</span></div><p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-zinc-600">{label}</p></Card>
}

function TeamsSection(props: {
  teams: Team[]
  newTeam: string
  setNewTeam: (value: string) => void
  editingTeam: number | null
  editingTeamName: string
  setEditingTeamName: (value: string) => void
  saving: boolean
  deleting: string | null
  onCreate: (event: FormEvent) => void
  onStartEdit: (team: Team) => void
  onSave: (id: number) => void
  onCancel: () => void
  onDelete: (team: Team) => void
}) {
  return <section className="mt-8 grid gap-8 lg:grid-cols-[360px_1fr]">
    <Card className="h-fit p-6 lg:sticky lg:top-24">
      <SectionHeading icon={<Plus />} title="Add team" description="Create a new tournament team." />
      <form onSubmit={props.onCreate} className="mt-6 space-y-3">
        <Input required maxLength={100} placeholder="e.g. Falcon Esports" value={props.newTeam} onChange={(e) => props.setNewTeam(e.target.value)} />
        <Button type="submit" loading={props.saving} className="w-full"><Plus className="size-4" /> Create team</Button>
      </form>
    </Card>
    <Card className="overflow-hidden">
      <div className="border-b border-white/10 px-6 py-5"><h2 className="font-mono text-xl font-bold">All teams</h2><p className="mt-1 text-sm text-zinc-600">Edit names or remove teams.</p></div>
      <div className="divide-y divide-white/5">
        {props.teams.map((team) => <div key={team.id} className="p-5">
          {props.editingTeam === team.id ? (
            <div className="flex flex-col gap-3 sm:flex-row"><Input autoFocus value={props.editingTeamName} onChange={(e) => props.setEditingTeamName(e.target.value)} /><div className="flex gap-2"><Button onClick={() => props.onSave(team.id)} loading={props.saving}><Save className="size-4" /> Save</Button><Button variant="ghost" onClick={props.onCancel}><X className="size-4" /> Cancel</Button></div></div>
          ) : (
            <div className="flex items-center gap-4"><span className="grid size-11 shrink-0 place-items-center rounded-xl bg-white/[.04] font-mono font-black text-zinc-400">{team.name.slice(0, 2).toUpperCase()}</span><div className="min-w-0 flex-1"><p className="truncate font-mono font-bold">{team.name}</p><p className="mt-1 text-xs text-zinc-600">ID #{team.id}</p></div><Button variant="ghost" onClick={() => props.onStartEdit(team)}><Edit3 className="size-4" /> Edit</Button><Button variant="danger" onClick={() => props.onDelete(team)} loading={props.deleting === `team-${team.id}`}><Trash2 className="size-4" /></Button></div>
          )}
        </div>)}
        {!props.teams.length && <EmptyState label="No teams yet." />}
      </div>
    </Card>
  </section>
}

function PlayersSection(props: {
  teams: Team[]
  players: Player[]
  playerByTeam: Map<number, Player[]>
  newPlayerName: string
  newPlayerTeam: number
  setNewPlayerName: (value: string) => void
  setNewPlayerTeam: (value: number) => void
  editingPlayer: number | null
  editingPlayerName: string
  editingPlayerTeam: number
  setEditingPlayerName: (value: string) => void
  setEditingPlayerTeam: (value: number) => void
  saving: boolean
  deleting: string | null
  onCreate: (event: FormEvent) => void
  onStartEdit: (player: Player) => void
  onSave: (id: number) => void
  onCancel: () => void
  onDelete: (player: Player) => void
}) {
  return <section className="mt-8 grid gap-8 lg:grid-cols-[360px_1fr]">
    <Card className="h-fit p-6 lg:sticky lg:top-24">
      <SectionHeading icon={<Plus />} title="Add player" description="Create a player and assign them to a team." />
      <form onSubmit={props.onCreate} className="mt-6 space-y-3">
        <select required value={props.newPlayerTeam} onChange={(e) => props.setNewPlayerTeam(Number(e.target.value))} className="w-full rounded-xl border border-white/10 bg-[#080b10] px-4 py-3 text-sm text-white outline-none focus:border-[#f4d35e]/60">
          <option value={0}>Select team</option>
          {props.teams.map((team) => <option key={team.id} value={team.id}>{team.name}</option>)}
        </select>
        <Input required maxLength={100} placeholder="Player nickname" value={props.newPlayerName} onChange={(e) => props.setNewPlayerName(e.target.value)} />
        <Button type="submit" loading={props.saving} className="w-full"><Plus className="size-4" /> Create player</Button>
      </form>
    </Card>
    <div className="space-y-5">
      {props.teams.map((team) => <Card key={team.id} className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-5"><div><h2 className="font-mono text-lg font-bold">{team.name}</h2><p className="mt-1 text-xs text-zinc-600">{props.playerByTeam.get(team.id)?.length ?? 0} players</p></div></div>
        <div className="divide-y divide-white/5">
          {(props.playerByTeam.get(team.id) ?? []).map((player) => props.editingPlayer === player.id ? (
            <div key={player.id} className="p-5 space-y-3">
              <div className="grid gap-3 md:grid-cols-[1fr_1fr_auto]"><Input autoFocus value={props.editingPlayerName} onChange={(e) => props.setEditingPlayerName(e.target.value)} /><select value={props.editingPlayerTeam} onChange={(e) => props.setEditingPlayerTeam(Number(e.target.value))} className="rounded-xl border border-white/10 bg-[#080b10] px-4 py-3 text-sm text-white outline-none"><option value={0}>Select team</option>{props.teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select><div className="flex gap-2"><Button onClick={() => props.onSave(player.id)} loading={props.saving}><Save className="size-4" /></Button><Button variant="ghost" onClick={props.onCancel}><X className="size-4" /></Button></div></div>
            </div>
          ) : (
            <div key={player.id} className="flex items-center gap-4 p-5"><div className="min-w-0 flex-1"><p className="font-mono font-bold">{player.nickname}</p><p className="mt-1 text-xs text-zinc-600">Player ID #{player.id}</p></div><Button variant="ghost" onClick={() => props.onStartEdit(player)}><Edit3 className="size-4" /> Edit</Button><Button variant="danger" onClick={() => props.onDelete(player)} loading={props.deleting === `player-${player.id}`}><Trash2 className="size-4" /></Button></div>
          ))}
          {!props.playerByTeam.get(team.id)?.length && <p className="px-5 py-6 text-sm text-zinc-600">No players in this team.</p>}
        </div>
      </Card>)}
      {!props.teams.length && <Card className="p-10"><EmptyState label="Create a team first, then add players." /></Card>}
    </div>
  </section>
}

function DaysSection(props: {
  teams: Team[]
  days: TournamentDay[]
  form: DayForm
  editingDay: number | null
  saving: boolean
  deleting: string | null
  setForm: React.Dispatch<React.SetStateAction<DayForm>>
  onToggleTeam: (teamId: number) => void
  onSubmit: (event: FormEvent) => void
  onStartEdit: (day: TournamentDay) => void
  onCancel: () => void
  onDelete: (day: TournamentDay) => void
}) {
  return <section className="mt-8 grid gap-8 lg:grid-cols-[420px_1fr]">
    <Card className="h-fit p-6 lg:sticky lg:top-24">
      <SectionHeading icon={<CalendarDays />} title={props.editingDay ? "Edit tournament day" : "Create tournament day"} description="A day has a custom name, participating teams, room count and deadline." />
      <form onSubmit={props.onSubmit} className="mt-6 space-y-4">
        <FieldLabel label="Tournament ID"><Input required type="number" min={1} value={props.form.tournament_id} onChange={(e) => props.setForm((f) => ({ ...f, tournament_id: Number(e.target.value) }))} /></FieldLabel>
        <FieldLabel label="Day name"><Input required placeholder="Day 1 - A × B" value={props.form.name} onChange={(e) => props.setForm((f) => ({ ...f, name: e.target.value }))} /></FieldLabel>
        <FieldLabel label="Deadline"><Input required type="datetime-local" value={props.form.deadline_at} onChange={(e) => props.setForm((f) => ({ ...f, deadline_at: e.target.value }))} /></FieldLabel>
        <FieldLabel label="Room count"><Input required min={1} type="number" value={props.form.room_count} onChange={(e) => props.setForm((f) => ({ ...f, room_count: Number(e.target.value) }))} /></FieldLabel>
        <FieldLabel label={`Participating teams (${props.form.teams.length})`}>
          <div className="grid max-h-64 gap-2 overflow-auto pr-1 sm:grid-cols-2">
            {props.teams.map((team) => { const active = props.form.teams.includes(team.id); return <button type="button" key={team.id} onClick={() => props.onToggleTeam(team.id)} className={`rounded-xl border px-3 py-3 text-left text-sm transition ${active ? "border-[#f4d35e]/50 bg-[#f4d35e]/10 text-[#f4d35e]" : "border-white/10 bg-white/[.02] text-zinc-500 hover:bg-white/[.05] hover:text-white"}`}><span className="font-semibold">{team.name}</span><span className="mt-1 block text-[10px] uppercase tracking-widest opacity-60">{active ? "Selected" : "Select"}</span></button> })}
          </div>
        </FieldLabel>
        <div className="flex gap-2 pt-2"><Button type="submit" loading={props.saving} className="flex-1"><Save className="size-4" /> {props.editingDay ? "Save changes" : "Create day"}</Button>{props.editingDay && <Button type="button" variant="ghost" onClick={props.onCancel}><X className="size-4" /> Cancel</Button>}</div>
      </form>
    </Card>

    <div className="space-y-4">
      {props.days.map((day) => <Card key={day.id} className="overflow-hidden"><div className="p-6"><div className="flex flex-col gap-5 md:flex-row md:items-start"><div className="grid size-12 shrink-0 place-items-center rounded-xl bg-[#f4d35e]/10 text-[#f4d35e]"><CalendarDays className="size-5" /></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="font-mono text-xl font-bold">{day.name}</h2>{props.editingDay === day.id && <span className="rounded-full bg-[#f4d35e]/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-[#f4d35e]">Editing</span>}</div><div className="mt-3 grid gap-2 text-sm text-zinc-500 sm:grid-cols-2"><span>Deadline: {new Date(day.deadline_at).toLocaleString()}</span><span>{day.room_count} rooms</span><span>{day.teams.length} participating teams</span><span>Tournament #{day.tournament_id}</span></div><div className="mt-4 flex flex-wrap gap-2">{day.teams.map((teamId) => <span key={teamId} className="rounded-full border border-white/10 bg-white/[.03] px-3 py-1.5 text-xs text-zinc-400">{props.teams.find((t) => t.id === teamId)?.name ?? `Team #${teamId}`}</span>)}</div></div><div className="flex shrink-0 gap-2"><Button variant="secondary" onClick={() => props.onStartEdit(day)}><Edit3 className="size-4" /> Edit</Button><Button variant="danger" onClick={() => props.onDelete(day)} loading={props.deleting === `day-${day.id}`}><Trash2 className="size-4" /></Button></div></div></div><div className="border-t border-white/5 bg-white/[.015] px-6 py-4"><Link href={`/schedule/${day.id}`} className="text-sm font-semibold text-[#f4d35e] hover:text-white">Open public day page <ChevronRight className="ml-1 inline size-4" /></Link><Link href="/admin/stats" className="ml-5 text-sm font-semibold text-zinc-500 hover:text-white">Enter room stats <ChevronRight className="ml-1 inline size-4" /></Link></div></Card>)}
      {!props.days.length && <Card className="p-10"><EmptyState label="No tournament days yet. Use the form to create the first one." /></Card>}
    </div>
  </section>
}

function SectionHeading({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return <div className="flex gap-3"><span className="mt-0.5 text-[#f4d35e]">{icon}</span><div><h2 className="font-mono text-xl font-bold">{title}</h2><p className="mt-1 text-sm leading-6 text-zinc-600">{description}</p></div></div>
}

function FieldLabel({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="mb-2 block text-[10px] font-bold uppercase tracking-[.18em] text-zinc-600">{label}</span>{children}</label>
}

function EmptyState({ label }: { label: string }) {
  return <div className="text-center text-sm text-zinc-600">{label}</div>
}
