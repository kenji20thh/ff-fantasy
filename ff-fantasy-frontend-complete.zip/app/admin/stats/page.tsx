"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { ArrowLeft, CheckCircle2, Save, ShieldCheck } from "lucide-react"
import { api } from "@/lib/api"
import type { Player, Room, RoomStat, Team, TournamentDay, User } from "@/lib/types"
import { Button, Card, ErrorBox, Input, Loading, PageTitle } from "@/components/ui"

type FormStat = { kills: number; assists: number; first_blood: boolean; placement: number }

const defaultStat = (): FormStat => ({ kills: 0, assists: 0, first_blood: false, placement: 1 })

export default function AdminStatsPage() {
  const [user, setUser] = useState<User | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [days, setDays] = useState<TournamentDay[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [players, setPlayers] = useState<Player[]>([])
  const [rooms, setRooms] = useState<Room[]>([])
  const [dayId, setDayId] = useState(0)
  const [roomId, setRoomId] = useState(0)
  const [stats, setStats] = useState<RoomStat[]>([])
  const [forms, setForms] = useState<Record<number, FormStat>>({})
  const [loading, setLoading] = useState(true)
  const [roomLoading, setRoomLoading] = useState(false)
  const [error, setError] = useState<unknown>(null)
  const [notice, setNotice] = useState("")
  const [saving, setSaving] = useState<number | null>(null)
  const [savingAll, setSavingAll] = useState(false)

  const day = days.find((item) => item.id === dayId)

  useEffect(() => {
    api.me()
      .then((me) => {
        setUser(me)
        if (me.role === "admin") loadBaseData()
      })
      .catch(setError)
      .finally(() => setAuthLoading(false))
  }, [])

  async function loadBaseData() {
    setLoading(true)
    setError(null)
    try {
      const [dayData, teamData] = await Promise.all([api.tournamentDays(), api.teams()])
      const playerData = await Promise.all(teamData.map((team) => api.players(team.id)))
      setDays(dayData)
      setTeams(teamData)
      setPlayers(playerData.flat())
    } catch (e) {
      setError(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!dayId) {
      setRooms([])
      setRoomId(0)
      return
    }
    setRoomLoading(true)
    setError(null)
    setRoomId(0)
    api.rooms(dayId).then(setRooms).catch(setError).finally(() => setRoomLoading(false))
  }, [dayId])

  useEffect(() => {
    if (!roomId) {
      setStats([])
      return
    }
    setRoomLoading(true)
    setError(null)
    api.roomStats(roomId).then(setStats).catch(setError).finally(() => setRoomLoading(false))
  }, [roomId])

  const relevantPlayers = useMemo(() => {
    if (!day) return []
    return players.filter((player) => day.teams.includes(player.team_id))
  }, [day, players])

  useEffect(() => {
    const next: Record<number, FormStat> = {}
    for (const player of relevantPlayers) {
      const stat = stats.find((item) => item.player_id === player.id)
      next[player.id] = stat
        ? { kills: stat.kills, assists: stat.assists, first_blood: stat.first_blood, placement: stat.placement }
        : defaultStat()
    }
    setForms(next)
  }, [relevantPlayers, stats])

  function updateForm(playerId: number, patch: Partial<FormStat>) {
    setForms((current) => ({ ...current, [playerId]: { ...(current[playerId] ?? defaultStat()), ...patch } }))
  }

  async function savePlayer(playerId: number) {
    if (!roomId) return
    setSaving(playerId)
    setError(null)
    setNotice("")
    try {
      const body = forms[playerId] ?? defaultStat()
      validateStat(body)
      const exists = stats.some((stat) => stat.player_id === playerId)
      if (exists) await api.adminUpdateStats(roomId, playerId, body)
      else await api.adminCreateStats(roomId, playerId, body)
      setStats(await api.roomStats(roomId))
      setNotice("Player stats saved.")
    } catch (e) {
      setError(e)
    } finally {
      setSaving(null)
    }
  }

  async function saveAll() {
    if (!roomId || !relevantPlayers.length) return
    setSavingAll(true)
    setError(null)
    setNotice("")
    try {
      for (const player of relevantPlayers) {
        const body = forms[player.id] ?? defaultStat()
        validateStat(body)
        const exists = stats.some((stat) => stat.player_id === player.id)
        if (exists) await api.adminUpdateStats(roomId, player.id, body)
        else await api.adminCreateStats(roomId, player.id, body)
      }
      setStats(await api.roomStats(roomId))
      setNotice(`Saved stats for ${relevantPlayers.length} players.`)
    } catch (e) {
      setError(e)
    } finally {
      setSavingAll(false)
    }
  }

  if (authLoading) return <Loading label="Checking admin access…" />
  if (!user) return <AccessCard title="Admin sign-in required" description="Log in with an administrator account to enter room statistics." />
  if (user.role !== "admin") return <AccessCard title="Access denied" description="Your account is not an administrator." />

  return (
    <main className="mx-auto max-w-7xl px-5 py-12 lg:px-8 lg:py-16">
      <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-zinc-500 hover:text-white"><ArrowLeft className="size-4" /> Admin control room</Link>
      <div className="mt-8 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <PageTitle eyebrow="Administration" title="Room statistics" description="Enter or update kills, assists, first blood and placement for every player in a room. The scoring rules stay in the Go backend." />
        {roomId && <Button onClick={saveAll} loading={savingAll}><Save className="size-4" /> Save all players</Button>}
      </div>

      <div className="mt-7 space-y-3"><ErrorBox error={error} />{notice && <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">{notice}</div>}</div>

      <div className="mt-8 grid gap-4 lg:grid-cols-2">
        <Card className="p-5"><label className="text-[10px] font-bold uppercase tracking-[.18em] text-zinc-600">Tournament day</label><select value={dayId} onChange={(e) => setDayId(Number(e.target.value))} className="mt-2 w-full rounded-xl border border-white/10 bg-[#080b10] px-4 py-3 text-sm text-white outline-none focus:border-[#f4d35e]/60"><option value={0}>Select tournament day</option>{days.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Card>
        <Card className="p-5"><label className="text-[10px] font-bold uppercase tracking-[.18em] text-zinc-600">Room</label><select disabled={!dayId || roomLoading} value={roomId} onChange={(e) => setRoomId(Number(e.target.value))} className="mt-2 w-full rounded-xl border border-white/10 bg-[#080b10] px-4 py-3 text-sm text-white outline-none disabled:opacity-40"><option value={0}>{roomLoading ? "Loading rooms…" : "Select room"}</option>{rooms.map((room) => <option key={room.id} value={room.id}>Room {room.room_number}</option>)}</select></Card>
      </div>

      {loading ? <div className="mt-8"><Loading label="Loading tournament data…" /></div> : !roomId || !day ? <Card className="mt-8 p-12 text-center"><ShieldCheck className="mx-auto size-8 text-[#f4d35e]" /><h2 className="mt-4 font-mono text-xl font-bold">Select a day and room</h2><p className="mt-2 text-sm text-zinc-600">The players shown below are limited to the teams participating in that tournament day.</p></Card> : <>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-3"><div><p className="font-mono text-xl font-bold">{day.name} · Room {rooms.find((room) => room.id === roomId)?.room_number}</p><p className="mt-1 text-sm text-zinc-600">{relevantPlayers.length} players in this room · {stats.length} stat records saved</p></div><span className="rounded-full border border-white/10 px-3 py-1.5 text-xs text-zinc-500">Scoring is calculated server-side</span></div>
        <div className="mt-5 space-y-3">
          {relevantPlayers.map((player) => {
            const form = forms[player.id] ?? defaultStat()
            const saved = stats.some((stat) => stat.player_id === player.id)
            const team = teams.find((item) => item.id === player.team_id)
            return <Card key={player.id} className="p-5"><div className="flex flex-col gap-5 xl:flex-row xl:items-center"><div className="min-w-48 flex-1"><div className="flex items-center gap-2"><p className="font-mono font-bold">{player.nickname}</p>{saved && <CheckCircle2 className="size-4 text-emerald-400" />}</div><p className="mt-1 text-xs text-zinc-600">{team?.name ?? `Team #${player.team_id}`} · Player #{player.id}</p></div><div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:w-[560px]"><StatField label="Kills" min={0} value={form.kills} onChange={(value) => updateForm(player.id, { kills: value })} /><StatField label="Assists" min={0} value={form.assists} onChange={(value) => updateForm(player.id, { assists: value })} /><StatField label="Placement" min={1} value={form.placement} onChange={(value) => updateForm(player.id, { placement: value })} /><label className="flex min-h-12 cursor-pointer items-center gap-2 rounded-xl border border-white/10 bg-white/[.02] px-3 text-xs text-zinc-400"><input type="checkbox" checked={form.first_blood} onChange={(e) => updateForm(player.id, { first_blood: e.target.checked })} /> First blood</label></div><Button onClick={() => savePlayer(player.id)} loading={saving === player.id}><Save className="size-4" /> Save</Button></div></Card>
          })}
          {!relevantPlayers.length && <Card className="p-10 text-center text-sm text-zinc-600">No players belong to the selected day. Add players to the participating teams first.</Card>}
        </div>
      </>}
    </main>
  )
}

function validateStat(stat: FormStat) {
  if (stat.kills < 0 || stat.assists < 0) throw new Error("Kills and assists cannot be negative.")
  if (stat.placement < 1) throw new Error("Placement must be at least 1.")
}

function StatField({ label, min, value, onChange }: { label: string; min: number; value: number; onChange: (value: number) => void }) {
  return <label className="block"><span className="mb-1 block text-[10px] uppercase tracking-widest text-zinc-600">{label}</span><Input min={min} type="number" value={value} onChange={(e) => onChange(Number(e.target.value))} /></label>
}

function AccessCard({ title, description }: { title: string; description: string }) {
  return <main className="mx-auto max-w-xl px-5 py-24 lg:px-8"><Card className="p-8"><ShieldCheck className="size-9 text-[#f4d35e]" /><h1 className="mt-5 font-mono text-3xl font-black">{title}</h1><p className="mt-3 text-sm leading-6 text-zinc-500">{description}</p><Link href="/admin" className="mt-6 inline-flex rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold">Back to admin</Link></Card></main>
}
