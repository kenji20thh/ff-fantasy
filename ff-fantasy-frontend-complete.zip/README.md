# FF Fantasy Frontend

Complete Next.js + TypeScript + Tailwind CSS frontend for the FF Fantasy Go backend.

## Requirements

- Node.js 20+
- Go backend running on `http://localhost:8080`
- Frontend running on `http://localhost:3000`

## Install

```bash
npm install
npm run dev
```

Optional `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8080
```

## Authentication

Authentication is cookie/session based. Every API request uses:

```ts
credentials: "include"
```

The frontend calls `GET /api/me` to determine the current user and role.

Admin access requires:

```ts
user.role === "admin"
```

The frontend check controls navigation/UI only. The Go backend remains the real authorization layer for all `/api/admin/*` mutations.

## Backend API used by this frontend

### Public GET

- `GET /api/teams`
- `GET /api/teams/{id}/players`
- `GET /api/rooms/{id}/stats`
- `GET /api/leaderboard`
- `GET /api/tournament-days`
- `GET /api/tournament-days/{id}`
- `GET /api/tournament-days/{id}/rooms`
- `GET /api/fantasy-teams/{id}`
- `GET /api/fantasy-teams/{id}/points`
- `GET /api/me`

### Authentication

- `POST /api/register`
- `POST /api/login`
- `POST /api/logout`

### Fantasy team

- `POST /api/fantasy-teams` — creates the team for the authenticated session; no user ID is sent by the frontend because the backend derives it from the session.
- `POST /api/fantasy-teams/{id}/players` with `{ "player_ids": [1,2,3,4] }`
- `POST /api/fantasy-teams/{id}/captain` with `{ "player_id": 1 }`

### Admin teams

- `POST /api/admin/teams` with `{ "name": "Team Alpha" }`
- `PUT /api/admin/teams/{id}` with `{ "name": "New Name" }`
- `DELETE /api/admin/teams/{id}`

### Admin players

- `POST /api/admin/players` with `{ "team_id": 1, "nickname": "PlayerName" }`
- `PUT /api/admin/players/{id}` with `{ "team_id": 2, "nickname": "NewName" }`
- `DELETE /api/admin/players/{id}`

### Admin tournament days

- `POST /api/admin/tournament-days`
- `PUT /api/admin/tournament-days/{id}`
- `DELETE /api/admin/tournament-days/{id}`

Example:

```json
{
  "tournament_id": 1,
  "name": "Day 1 - A × B",
  "teams": [1, 2, 3],
  "room_count": 4,
  "deadline_at": "2026-09-11T19:00:00+01:00"
}
```

### Admin room statistics

- `POST /api/admin/rooms/{room_id}/stats/{player_id}`
- `PUT /api/admin/rooms/{room_id}/stats/{player_id}`

Example:

```json
{
  "kills": 10,
  "assists": 4,
  "first_blood": true,
  "placement": 1
}
```

Existing stats are read with the public endpoint:

```text
GET /api/rooms/{id}/stats
```

The admin stats page decides POST vs PUT by checking whether that player already has a stat record for the selected room.

## Important design rules

- Tournament organization is by **days**, not groups.
- Day names are arbitrary admin-entered strings such as `Day 1 - A × B`.
- Exactly four fantasy players are required.
- Fantasy players must come from four different real teams.
- One captain is selected from the four players.
- Scoring is calculated by the Go backend; the frontend does not replace the server-side scoring rules.
- No fake endpoints are used.
- Rooms are created/removed by the tournament-day backend logic. The frontend does not invent a separate room CRUD API.
